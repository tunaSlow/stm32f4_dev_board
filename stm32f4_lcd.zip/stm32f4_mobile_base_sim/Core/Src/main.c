/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306/ssd1306.h"
#include "ssd1306/ssd1306_fonts.h"
#include "usbd_cdc_if.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define LM75A_ADDR  (0x4F << 1)  // Shifted for HAL (8-bit address mode)
#define LM75A_TEMP_REG 0x00
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void I2C_ScanAndDisplay(void)
{
	char buf[20];
	ssd1306_Fill(Black);
	ssd1306_SetCursor(0, 0);
	ssd1306_WriteString("I2C Scan:", Font_7x10, White);

	uint8_t found = 0;
	uint8_t y = 12; // OLED row position

	for (uint8_t addr = 1; addr < 127; addr++)
	{
		if (HAL_I2C_IsDeviceReady(&hi2c2, (addr << 1), 3, 5) == HAL_OK)
		{
			snprintf(buf, sizeof(buf), "0x%02X", addr);
			ssd1306_SetCursor(0, y);
			ssd1306_WriteString(buf, Font_7x10, White);
			y += 10;
			found = 1;
		}
	}

	if (!found)
	{
		ssd1306_SetCursor(2, 12);
		ssd1306_WriteString("No device!", Font_7x10, White);
	}

	ssd1306_UpdateScreen();
}

#define LM75A_TEMP_REG  0x00
uint8_t lm75a_addr = 0; // Will be set after scan

void I2C_ScanAndFindLM75A(void)
{
	for (uint8_t addr = 1; addr < 127; addr++)
	{
		if (HAL_I2C_IsDeviceReady(&hi2c2, (addr << 1), 3, 5) == HAL_OK)
		{
			if (addr == 0x4F) // Found LM75A
			{
				lm75a_addr = addr << 1; // Save 8-bit form for HAL
				break;
			}
		}
	}
}

float LM75A_ReadTemperature_Fine(void)
{
	uint8_t temp_data[2];
	int16_t raw_temp;
	float temperature;

	if (HAL_I2C_Mem_Read(&hi2c2, lm75a_addr, LM75A_TEMP_REG,
			I2C_MEMADD_SIZE_8BIT, temp_data, 2, HAL_MAX_DELAY) != HAL_OK)
	{
		return -1000.0f; // Error
	}

	// Combine MSB and LSB
	raw_temp = (temp_data[0] << 8) | temp_data[1];

	// Shift right by 5 to get rid of unused bits (bits 4..0)
	raw_temp >>= 5;

	// Sign extend 11-bit signed number if needed
	if (raw_temp & 0x400) // Check sign bit (bit 10)
	{
		raw_temp |= 0xF800; // Set upper bits to 1 for negative numbers
	}

	temperature = raw_temp * 0.125f;

	return temperature;
}


extern float vx_f, vy_f, vw_f;  // Declare these as extern if defined globally

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	// Turn on LCD backlight
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);  // Adjust pin and port as needed

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_ADC1_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
	ssd1306_Init();
	I2C_ScanAndFindLM75A();


	char buffer[32];

	char line[24];


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{

		float temp = LM75A_ReadTemperature_Fine();
		uint32_t adc_val = Read_ADC_Channel();
		float voltage = adc_val * 3.3f / 4095.0f;

		// Clear the display

		//		SSD1306_Clear();
		ssd1306_Fill(Black);

		// Line 1: Temperature
		ssd1306_SetCursor(2, 0);
		snprintf(buffer, sizeof(buffer), "Temp: %d.%02d C",
				(int)temp, (int)((temp - (int)temp) * 100));
		ssd1306_WriteString(buffer, Font_7x10, White);

		// Line 2: Potentiometer
		ssd1306_SetCursor(2, 12);
		snprintf(buffer, sizeof(buffer), "Pot: %ld (%.2fV)", adc_val, voltage);
		ssd1306_WriteString(buffer, Font_7x10, White);


		//
		// Vx
		ssd1306_SetCursor(2, 24);
		snprintf(buffer, sizeof(buffer), "Vx: %.3f", vx_f);
		ssd1306_WriteString(buffer, Font_7x10, White);

		// Vy
		ssd1306_SetCursor(2, 36);
		snprintf(buffer, sizeof(buffer), "Vy: %.3f", vy_f);
		ssd1306_WriteString(buffer, Font_7x10, White);

		// Vw
		ssd1306_SetCursor(2, 48);
		snprintf(buffer, sizeof(buffer), "Vw: %.3f", vw_f);
		ssd1306_WriteString(buffer, Font_7x10, White);



		// Update the display
		ssd1306_UpdateScreen();

		HAL_Delay(50);
	}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
